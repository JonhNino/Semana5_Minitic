package com.unab.g01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class G01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
